package com.example.locationfinderapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.example.locationfinderapplication.databinding.ActivityPointsListBinding;
import com.example.locationfinderapplication.databinding.ActivitySearchPointsBinding;

import java.util.ArrayList;
//list of all entries, clicking entries takes to the modification page
public class PointsList extends AppCompatActivity {

    private ArrayList<String> id, name, address;
    private ArrayList<Double> latitude, longitude;
    String views;
    private ActivityPointsListBinding binding;
    Database db;
    RecyclerViewAdapter adapter;
    RecyclerView rView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityPointsListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = new Database(PointsList.this);
        id = new ArrayList<>();
        name = new ArrayList<>();
        latitude = new ArrayList<>();
        longitude = new ArrayList<>();
        address = new ArrayList<>();
        views = "PointsList";

        //initialize data in the list view
        pullData();

        //recycler view and adapter objects to show all the entries
        adapter = new RecyclerViewAdapter(PointsList.this, PointsList.this, id, name, latitude, longitude, address, views);
        rView = findViewById(R.id.recView);

        rView.setAdapter(adapter);
        rView.setLayoutManager(new LinearLayoutManager(PointsList.this));
    }

    //read all data from database, display here
    private void pullData(){
        Cursor cursor = db.readData();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "Table is Empty.", Toast.LENGTH_LONG).show();
        }else{
            while(cursor.moveToNext()){
                id.add(cursor.getString(0));
                name.add(cursor.getString(1));
                latitude.add(cursor.getDouble(2));
                longitude.add(cursor.getDouble(3));
                address.add(cursor.getString(4));
            }
        }
    }

}