package com.example.locationfinderapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.locationfinderapplication.databinding.ActivitySearchPointsBinding;

import java.util.ArrayList;
//user can search through database here by name or address
public class SearchPoints extends AppCompatActivity {

    private Context context;
    private ArrayList<String> id, name, address;
    private ArrayList<Double> latitude, longitude;
    String views;
    private ActivitySearchPointsBinding binding;
    Database db;
    Activity activity;
    RecyclerViewAdapter adapter;
    RecyclerView rView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySearchPointsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = new Database(SearchPoints.this);
        id = new ArrayList<>();
        name = new ArrayList<>();
        latitude = new ArrayList<>();
        longitude = new ArrayList<>();
        address = new ArrayList<>();
        views = "SearchPoints";

        //initialize data in the search view
        pullData();

        //set up recycler view objects to view
        adapter = new RecyclerViewAdapter(SearchPoints.this, SearchPoints.this, id, name, latitude, longitude, address, views);
        rView = findViewById(R.id.rv);

        rView.setAdapter(adapter);
        rView.setLayoutManager(new LinearLayoutManager(SearchPoints.this));

        //search by name entry button
        binding.entName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = binding.nameSearch.getText().toString();

                //only works if input is not empty
                if(!query.isEmpty()){
                    //clear the recycle view and the arraylists of values
                    clearLists();
                    adapter.notifyDataSetChanged();

                    //make query
                    queryName(query);

                    //only show values that matched the query
                    adapter = new RecyclerViewAdapter(SearchPoints.this, SearchPoints.this, id, name, latitude, longitude, address, views);
                    rView.setAdapter(adapter);
                    rView.setLayoutManager(new LinearLayoutManager(SearchPoints.this));
                }

            }
        });

        //search by address entry button
        binding.entAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = binding.addressSearch.getText().toString();

                //only works if the input is not empty
                if(!query.isEmpty()){
                    //clear the recycle view and the arraylists of values
                    clearLists();
                    adapter.notifyDataSetChanged();

                    //make query
                    queryAddress(query);

                    //only show values that matched the query
                    adapter = new RecyclerViewAdapter(SearchPoints.this, SearchPoints.this, id, name, latitude, longitude, address, views);
                    rView.setAdapter(adapter);
                    rView.setLayoutManager(new LinearLayoutManager(SearchPoints.this));
                }
            }
        });

        //reset the search view and the input boxes
        binding.clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearLists();
                adapter.notifyDataSetChanged();

                pullData();

                adapter = new RecyclerViewAdapter(SearchPoints.this, SearchPoints.this, id, name, latitude, longitude, address, views);
                rView.setAdapter(adapter);
                rView.setLayoutManager(new LinearLayoutManager(SearchPoints.this));

                binding.nameSearch.setText("");
                binding.addressSearch.setText("");
            }
        });
    }

    //read all entries from the database
    private void pullData(){
        Cursor cursor = db.readData();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "Table is Empty.", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                id.add(cursor.getString(0));
                name.add(cursor.getString(1));
                latitude.add(cursor.getDouble(2));
                longitude.add(cursor.getDouble(3));
                address.add(cursor.getString(4));
            }
        }
    }

    //clear all the arraylists
    private void clearLists(){
        id.clear();
        name.clear();
        latitude.clear();
        longitude.clear();
        address.clear();
    }

    //reinitialize arraylists with matches from the query
    private void queryName(String query){
        Cursor cursor = db.queryDataName(query);

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No locations match this search.", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                id.add(cursor.getString(0));
                name.add(cursor.getString(1));
                latitude.add(cursor.getDouble(2));
                longitude.add(cursor.getDouble(3));
                address.add(cursor.getString(4));
            }
        }
    }

    //reinitialize arraylists with matches from the query
    private void queryAddress(String query){
        Cursor cursor = db.queryDataAddress(query);

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No locations match this search.", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                id.add(cursor.getString(0));
                name.add(cursor.getString(1));
                latitude.add(cursor.getDouble(2));
                longitude.add(cursor.getDouble(3));
                address.add(cursor.getString(4));
            }
        }
    }
}