package com.example.locationfinderapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.locationfinderapplication.databinding.ActivityAddPointBinding;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Locale;
//this activity is where users can add entries to the database
public class AddPoint extends AppCompatActivity {

    private ActivityAddPointBinding binding;
    private String name, address;
    private double lat, lon;
    Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //set view
        binding = ActivityAddPointBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        database = new Database(AddPoint.this);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setNegativeButton(
                "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        //waiting for the 'add' button to be pressed
        binding.addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cLat, cLon;

                name = binding.addName.getText().toString();
                cLat = binding.addLat.getText().toString();
                cLon = binding.addLon.getText().toString();

                //check that none of the inputs are empty
                if(name.isEmpty()){
                    alert.setMessage("Please give this waypoint a name.");
                    alert.setCancelable(true);
                    alert.show();
                }else if(cLat.isEmpty()){
                    alert.setMessage("Latitude is required.");
                    alert.setCancelable(true);
                    alert.show();
                }else if(cLon.isEmpty()){
                    alert.setMessage("Longitude is required.");
                    alert.setCancelable(true);
                    alert.show();
                }else {
                    lat = Double.parseDouble(cLat);
                    lon = Double.parseDouble(cLon);
                    //check the lat and lon constraints
                    if(lat < -90 || lat > 90) {
                        alert.setMessage("Longitude must be between -90 and 90.");
                        alert.setCancelable(true);
                        alert.show();
                    }else if(lon < -180 || lon > 180) {
                        alert.setMessage("Longitude must be between -180 and 180.");
                        alert.setCancelable(true);
                        alert.show();
                    }else {
                        //fetch the address
                        address = getAddress(lat, lon);

                        if(address.isEmpty()){
                            alert.setMessage("Failed to get address, try again.");
                            alert.setCancelable(true);
                            alert.show();
                        }else{
                            //add to database and clear inputs
                            database.add(name, lat, lon, address);
                            binding.addName.setText("");
                            binding.addLat.setText("");
                            binding.addLon.setText("");
                        }
                    }
                }
            }
        });

        //this button allows users to fill database with 50 predetermined entries
        binding.addCSV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alert.setTitle("Reset with CSV Entries");
                alert.setMessage("Are you sure you want to input the 50 CSV points? This will empty all the current entries from the application.");
                alert.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int i) {
                                CSVInput();
                            }
                        });
                alert.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                alert.show();
            }
        });
    }

    public void CSVInput(){
        //get database instance, create input path
        database = new Database(AddPoint.this);
        InputStream in = getResources().openRawResource(R.raw.lat_lon);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        //reset the database to 0 entries
        database.resetDatabase();

        try{
            String entry;

            //get each entry, divide attributes, get address, add to database
            while((entry = reader.readLine()) != null){
                String[] attributes = entry.split(",");
                name = attributes[0];
                lat = Double.parseDouble(attributes[1]);
                lon = Double.parseDouble(attributes[2]);
                address = getAddress(lat, lon);

                database.add(name, lat, lon, address);
            }

            //close input stream
            in.close();
        }catch(Exception e){
            Toast.makeText(this, "Failed to read CSV file.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }

    //get address of location using geocoder and lat/lon
    public String getAddress(double lat, double lon){
        List<Address> newAddress = null;
        Geocoder geoCoder;
        geoCoder = new Geocoder(AddPoint.this, Locale.getDefault());

        try{
            newAddress = geoCoder.getFromLocation(lat, lon, 1);
            return newAddress.get(0).getAddressLine(0);
        }catch(Exception e){
            e.printStackTrace();
        }
        return "";
    }
}