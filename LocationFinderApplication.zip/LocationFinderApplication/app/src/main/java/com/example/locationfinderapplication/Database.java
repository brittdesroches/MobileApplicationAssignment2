package com.example.locationfinderapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

//Database interface, no activity associated
public class Database extends SQLiteOpenHelper{

    private Context context;
    private static final String DBNAME = "locations.db";
    private static final int DBVERSION = 1;

    private static final String TABLE_NAME = "Waypoints";
    private static final String ID = "_id";
    private static final String NAME = "name";
    private static final String LATITUDE = "lat";
    private static final String LONGITUDE = "lon";
    private static final String ADDRESS = "address";

    Database(@Nullable Context context){
        super(context, DBNAME, null, DBVERSION);
        this.context = context;
    }

    //create table
    @Override
    public void onCreate(SQLiteDatabase database){
        String createTable =
                "CREATE TABLE " + TABLE_NAME +
                        " (" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        NAME + " TEXT, " +
                        LATITUDE + " REAL, " +
                        LONGITUDE + " REAL, " +
                        ADDRESS + " TEXT); ";
        database.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int i, int j){
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(database);
    }

    //add entries to the database
    public void add(String name, double lat, double lon, String address){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues content = new ContentValues();

        content.put(NAME, name);
        content.put(LATITUDE, lat);
        content.put(LONGITUDE, lon);
        content.put(ADDRESS, address);

        long success = database.insert(TABLE_NAME, null, content);

        if(success == -1){
            Toast.makeText(context, "Add unsuccessful.", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Add successful.", Toast.LENGTH_SHORT).show();
        }
    }

    //delete entries from the database
    public void delete(String entry_id){
        SQLiteDatabase database = this.getWritableDatabase();

        long success = database.delete(TABLE_NAME, "_id=?", new String[]{entry_id});

        if(success == -1){
            Toast.makeText(context, "Delete unsuccessful.", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Delete successful.", Toast.LENGTH_SHORT).show();
        }
    }

    //update the values from the specified entry
    public void update(String id, String name, double lat, double lon, String address){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues content = new ContentValues();

        content.put(NAME, name);
        content.put(LATITUDE, lat);
        content.put(LONGITUDE, lon);
        content.put(ADDRESS, address);

        long success = database.update(TABLE_NAME, content, "_id=?", new String[]{id});

        if(success == -1){
            Toast.makeText(context, "Update unsuccessful.", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Update successful.", Toast.LENGTH_SHORT).show();
        }
    }

    //search database by name of entry
    public Cursor queryDataName(String name){
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE NAME LIKE '%" + name + "%'";
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = null;

        if(database != null){
            cursor = database.rawQuery(query, null);
        }

        return cursor;
    }

    //search database by address of entry
    public Cursor queryDataAddress(String address){
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE ADDRESS LIKE '%" + address + "%'";
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = null;

        if(database != null){
            cursor = database.rawQuery(query, null);
        }

        return cursor;
    }

    //read all values from database
    public Cursor readData(){
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase database = this.getReadableDatabase();

        Cursor cursor = null;
        if(database != null){
            cursor = database.rawQuery(query, null);
        }

        return cursor;
    }

    //delete all from database
    public void resetDatabase(){
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL("DELETE FROM " + TABLE_NAME);
    }
}
