package com.example.locationfinderapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;

import com.example.locationfinderapplication.databinding.ActivityModifyBinding;
//where the user can delete or update entries
public class ModifyActivity extends AppCompatActivity {

    private ActivityModifyBinding binding;
    private String id, name, address;
    private double lat, lon;
    Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityModifyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setData();
        database = new Database(ModifyActivity.this);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        Intent goBack = new Intent(ModifyActivity.this, PointsList.class);

        //wait for delete button to be pressed
        binding.delBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //make sure the user meant to press the button
                alert.setTitle("Delete Waypoint");
                alert.setMessage("Are you sure you want to delete this waypoint?");
                alert.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int i) {
                                //get id from cardview and delete entry. Return to the list view
                                database.delete(id);
                                ModifyActivity.this.startActivity(goBack);
                            }
                        });
                alert.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                alert.show();
            }
        });

        //wait for update button to be pressed
        binding.upBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //ensure this is what the user wants
                alert.setTitle("Confirm Update");
                alert.setMessage("Are you sure you want to update this waypoint?");
                alert.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int i) {
                                String cLat, cLon;

                                name = binding.upName.getText().toString();
                                cLat = binding.upLat.getText().toString();
                                cLon = binding.upLon.getText().toString();
                                address = binding.upAddress.getText().toString();

                                //ensure no entry is empty
                                if(name.isEmpty()){
                                    alert.setMessage("Please give this waypoint a name.");
                                    alert.setCancelable(true);
                                    alert.show();
                                }else if(cLat.isEmpty()){
                                    alert.setMessage("Latitude is required.");
                                    alert.setCancelable(true);
                                    alert.show();
                                }else if(cLon.isEmpty()){
                                    alert.setMessage("Longitude is required.");
                                    alert.setCancelable(true);
                                    alert.show();
                                }else {
                                    lat = Double.parseDouble(cLat);
                                    lon = Double.parseDouble(cLon);

                                    //check constraints
                                    if(lat < -90 || lat > 90) {
                                        alert.setMessage("Longitude must be between -90 and 90.");
                                        alert.setCancelable(true);
                                        alert.show();
                                    }else if(lon < -180 || lon > 180) {
                                        alert.setMessage("Longitude must be between -180 and 180.");
                                        alert.setCancelable(true);
                                        alert.show();
                                    }else {
                                        //update the values in the database, go back to list view
                                        database.update(id, name, lat, lon, address);
                                        ModifyActivity.this.startActivity(goBack);
                                    }
                                }
                            }
                        });
                alert.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                alert.show();
            }
        });
    }

    //initializes data in the search view
    public void setData(){
        id = getIntent().getStringExtra("id");
        name = getIntent().getStringExtra("name");
        lat = Double.parseDouble(getIntent().getStringExtra("lat"));
        lon = Double.parseDouble(getIntent().getStringExtra("lon"));
        address = getIntent().getStringExtra("address");

        //previous data in textedits for reference
        binding.upName.setText(name);
        binding.upLat.setText(String.valueOf(lat));
        binding.upLon.setText(String.valueOf(lon));
        binding.upAddress.setText(address);
    }
}