package com.example.locationfinderapplication;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Objects;
//here is where all the entry cards are created
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyView>{

    private Context context;
    private ArrayList<String> id, name, address;
    private ArrayList<Double> lat, lon;
    Activity activity;
    String views;

    RecyclerViewAdapter(Activity activity, Context context, ArrayList<String> id, ArrayList<String> name, ArrayList<Double> latitude, ArrayList<Double> longitude, ArrayList<String> address, String views){
        this.context = context;
        this.activity = activity;
        this.id = id;
        this.name = name;
        this.lat = latitude;
        this.lon = longitude;
        this.address = address;
        this.views = views;
    }

    //initialize the layout of each of the cards from point_card_layout.xml
    @NonNull
    @Override
    public MyView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.point_card_layout, parent, false);
        return new MyView(view);
    }

    //set the different attributes in the card view for the recycler view areas of the app
    @Override
    public void onBindViewHolder(@NonNull MyView holder, @SuppressLint("RecyclerView") int position) {
        String lats, lons, addresses;
        lats = "Latitude: " + String.valueOf(lat.get(position));
        lons = "Longitude: " + String.valueOf(lon.get(position));
        addresses = "Address: " + String.valueOf(address.get(position));

        holder.name.setText(String.valueOf(name.get(position)));
        holder.latitude.setText(lats);
        holder.longitude.setText(lons);
        holder.address.setText(addresses);

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println(context);
                System.out.println(activity);
                //can only get to modification page going through the List page since the Search page also has recycler view items
                if(views.equals("PointsList")){
                    //bundle attributes, send to modification page
                    Intent intent = new Intent(context, ModifyActivity.class);
                    intent.putExtra("id", String.valueOf(id.get(position)));
                    intent.putExtra("name", String.valueOf(name.get(position)));
                    intent.putExtra("lat", String.valueOf(lat.get(position)));
                    intent.putExtra("lon", String.valueOf(lon.get(position)));
                    intent.putExtra("address", String.valueOf(address.get(position)));

                    activity.startActivityForResult(intent, 1);

                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return address.size();
    }

    //initializes the views from the point_card_layout to their values
    public class MyView extends RecyclerView.ViewHolder {
        TextView name, latitude, longitude, address;
        LinearLayout card;

        public MyView(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            latitude = itemView.findViewById(R.id.latitude);
            longitude = itemView.findViewById(R.id.longitude);
            address = itemView.findViewById(R.id.address);
            card = itemView.findViewById(R.id.card);
        }
    }
}
