package com.example.locationfinderapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.locationfinderapplication.databinding.ActivityMainPageBinding;
//Main page of the app
public class MainPageActivity extends AppCompatActivity {

    private ActivityMainPageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        Database database = new Database(this);

        //go to the search page
        binding.search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent searchActivity = new Intent(MainPageActivity.this, SearchPoints.class);
                MainPageActivity.this.startActivity(searchActivity);
            }
        });

        //go to the add page
        binding.query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent queryActivity = new Intent(MainPageActivity.this, AddPoint.class);
                MainPageActivity.this.startActivity(queryActivity);
            }
        });

        //go to the update page
        binding.list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent listActivity = new Intent(MainPageActivity.this, PointsList.class);
                MainPageActivity.this.startActivity(listActivity);
            }
        });
    }
}